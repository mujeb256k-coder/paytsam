const pages = document.querySelectorAll(".page");
const navItems = document.querySelectorAll(".nav-item");
const modal = document.getElementById("modal");
const modalContent = document.getElementById("modalContent");

let balance = 12450.00;
let balanceVisible = true;
let transactions = [
  {name:"Received from Rahul", type:"received", amount:850, date:"Today • 10:24 AM", icon:"↓"},
  {name:"Airtel Recharge", type:"sent", amount:-299, date:"Yesterday • 8:12 PM", icon:"📱"},
  {name:"Coffee Shop", type:"sent", amount:-180, date:"Oct 2 • 6:40 PM", icon:"☕"},
  {name:"Received from Priya", type:"received", amount:1200, date:"Oct 1 • 11:15 AM", icon:"↓"},
  {name:"Electricity Bill", type:"sent", amount:-640, date:"Sep 30 • 7:31 PM", icon:"💡"}
];

function renderTransactions(targetId, list=transactions) {
  const el = document.getElementById(targetId);
  el.innerHTML = list.map(tx => `
    <div class="transaction">
      <div class="tx-icon">${tx.icon}</div>
      <div class="tx-info"><b>${tx.name}</b><p>${tx.date}</p></div>
      <div class="tx-amount ${tx.type}">${tx.amount > 0 ? "+" : "-"}₹${Math.abs(tx.amount).toFixed(2)}</div>
    </div>`).join("");
}
renderTransactions("recentTransactions", transactions.slice(0,4));
renderTransactions("allTransactions");

function showPage(id) {
  pages.forEach(p => p.classList.toggle("active", p.id === id));
  navItems.forEach(n => n.classList.toggle("active", n.dataset.page === id));
  window.scrollTo({top:0, behavior:"smooth"});
}

document.querySelectorAll("[data-page]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.page));
});

document.querySelectorAll("[data-home]").forEach(btn => btn.addEventListener("click", () => showPage("homePage")));

document.querySelectorAll("[data-action]").forEach(btn => {
  btn.addEventListener("click", () => {
    const action = btn.dataset.action;
    if (action === "scan") showPage("scanPage");
    if (action === "send" || action === "bank" || action === "request") openPaymentModal(action);
  });
});

document.getElementById("toggleBalance").addEventListener("click", () => {
  balanceVisible = !balanceVisible;
  document.getElementById("balance").textContent = balanceVisible ? balance.toFixed(2) : "••••";
});

document.getElementById("copyUpi").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText("mujeb@paytsam"); } catch(e) {}
  toast("UPI ID copied");
});

document.getElementById("profileBtn").addEventListener("click", () => showPage("profilePage"));
document.getElementById("notificationBtn").addEventListener("click", () => toast("No new notifications"));

document.getElementById("demoScan").addEventListener("click", () => {
  openModal(`
    <div class="success-icon">▦</div>
    <h2>Demo QR detected</h2>
    <p>This is a UI demo. No real payment will be made.</p>
    <div class="demo-box"><b>Merchant:</b> Demo Store<br><b>UPI:</b> demostore@upi</div>
    <button class="primary-btn" onclick="closeModal()">Cancel</button>
  `);
});

document.getElementById("sendForm").addEventListener("submit", e => {
  e.preventDefault();
  const receiver = document.getElementById("receiver").value.trim();
  const amount = Number(document.getElementById("sendAmount").value);
  if (!receiver || !amount || amount <= 0) return toast("Enter a valid UPI ID and amount");
  if (amount > balance) return toast("Insufficient demo balance");
  openPaymentModal("send", receiver, amount);
});

function openPaymentModal(action, receiver="", amount=0) {
  if (action === "send") {
    modalContent.innerHTML = `
      <h2>Confirm payment</h2>
      <p>Demo transaction • no real money will move</p>
      <div class="confirm-amount">₹${amount.toFixed(2)}</div>
      <div class="demo-box"><b>To:</b> ${escapeHtml(receiver)}<br><b>From:</b> mujeb@paytsam</div>
      <button class="primary-btn" id="confirmPayment">Pay ₹${amount.toFixed(2)}</button>`;
    document.getElementById("confirmPayment").onclick = () => {
      balance -= amount;
      transactions.unshift({
        name: "Sent to " + receiver,
        type: "sent", amount: -amount,
        date: "Just now", icon: "↗"
      });
      document.getElementById("balance").textContent = balance.toFixed(2);
      renderTransactions("recentTransactions", transactions.slice(0,4));
      renderTransactions("allTransactions");
      closeModal();
      showPage("historyPage");
      toast("Demo payment successful");
      document.getElementById("sendForm").reset();
    };
  } else if (action === "bank") {
    modalContent.innerHTML = `<h2>Bank Transfer</h2><p>Choose how you want to transfer.</p>
      <div class="demo-box">🏦 Account Number + IFSC<br><br>📱 UPI ID / Mobile<br><br>⚠️ Demo only — banking integration is not connected.</div>
      <button class="primary-btn" onclick="closeModal()">Continue</button>`;
  } else {
    modalContent.innerHTML = `<h2>Request Money</h2><p>Create a collect request from another UPI user.</p>
      <div class="demo-box">Enter UPI ID and request amount in the production version.</div>
      <button class="primary-btn" onclick="closeModal()">Done</button>`;
  }
  openModal();
}

function openModal(content) {
  if (content) modalContent.innerHTML = content;
  modal.classList.add("show");
}
function closeModal() { modal.classList.remove("show"); }
document.getElementById("modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });

function toast(message) {
  const old = document.querySelector(".toast");
  if (old) old.remove();
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = message;
  Object.assign(t.style,{position:"fixed",left:"50%",bottom:"95px",transform:"translateX(-50%)",background:"#171b2d",color:"#fff",padding:"11px 17px",borderRadius:"30px",fontSize:"12px",zIndex:200,boxShadow:"0 8px 20px #0003"});
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),1800);
}
function escapeHtml(str) {
  return str.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
